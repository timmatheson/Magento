require 'autotest'
require 'rubygems'
require 'redgreen'
require 'test/unit'
require 'magento'



