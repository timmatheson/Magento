module Magento
  class Product
  end
end