require 'magento'
module Magento
  class Invoice < Abstract
     
  end
end