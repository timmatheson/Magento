module Magento
  class Server
  end
end