module Magento
  class ProductImages
  end
end 