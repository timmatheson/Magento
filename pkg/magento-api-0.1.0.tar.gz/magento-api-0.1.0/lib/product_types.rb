module Magento
  class ProductTypes
  end
end